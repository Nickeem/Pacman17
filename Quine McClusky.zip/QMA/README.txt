Brief insructions for applications:
Minterms are number representations of terms i.e. 0: A'B'C'. When entering Minterms seperate them by commas. 
Example: 0, 1, 2, 7

Number of variables field means the number of terms to be represented. 
Example: ABC or ABCDE

Minterms are to be in range of 0 - 31 inclusive. Using other numbers may cause errors
Number of terms to use is limited to 5 so the program space usage is limited.

INPUT CASE:
Minterms: 1,2,3,4
Number of  variables: 4
PRESS Solve button

Version 1 of the program handles how many terms are used automatically, while in version 1 this is entered manually

NOT most effiecient method implementation in some cases because of greedy algorithm approach

Code might be published freely at github.com/Pacman17/