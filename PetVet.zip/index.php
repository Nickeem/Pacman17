<?php # Script 7.6 - view_students.php (2nd version after Script 7.4)
// This script retrieves all the records from the students table.

$page_title = 'Welcome to Pet Vet';
include ('includes/header.php');

// Page header.
echo '<h1 id="mainhead">Welcome to Pet Vet</h1>';

// Page menu.
include ('includes/menu.php');

	echo "<p align='center'>Please select a task to perform.</p>\n";


include ('includes/footer.php'); // Include the HTML footer.
?>