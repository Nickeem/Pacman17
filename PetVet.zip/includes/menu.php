<?php // 

echo '<P align="center"><a href="view_owners.php">View All Owners</a> | <a href="search_pets.php">Search for a Pet</a> | <a href="register_pet.php">Add a New Pet</a></P>';
?>