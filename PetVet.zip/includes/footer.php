		<!-- End of page-specific content. -->
		<!-- start footer.php -->
	</div><!-- End of "content" DIV. -->
		</td>
	</tr>

	<tr>
		<td>
	<br><div class="textsmall" align="center"><p>&copy; Copyright 2021 by Tessa King-Inniss</p></div>
	
</div><!-- End of "wrapper" DIV. -->
		</td>
	</tr>
</table>
</body>
</html>