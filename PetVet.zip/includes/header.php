<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
	<title><?php echo $page_title; ?></title>
	<link href="BCStyle.css" rel="STYLESHEET" type="text/css">
</head>
<body bgcolor="#F6E8A6">
<div id="wrapper"><!-- Goes with the CSS layout. -->

	<div id="content"><!-- Goes with the CSS layout. -->

		<div align="center"><!-- Logo and links -->
		
<table border="0" cellspacing="0" cellpadding="0" width="800" height="100%">
	<tr>
		<td align="center"><h1>Pet Vet</h1></td>
	</tr>
	<tr>
		<td>
		</div>
		<!-- end of header.php -->
		<!-- Start of page-specific content. -->